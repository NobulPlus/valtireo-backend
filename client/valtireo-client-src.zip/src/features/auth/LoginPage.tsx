import { useId, useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Eye, EyeOff } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { ApiError } from '@/lib/apiClient';
import { Field } from '@/components/ui/Field';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Alert';
import { Logomark } from '@/components/ui/Logomark';

const schema = z.object({
  email: z.string().min(1, 'Enter your email address').email('Enter a valid email address'),
  password: z.string().min(1, 'Enter your password'),
});

type FormValues = z.infer<typeof schema>;

const PILLARS = [
  'Every employee record complete, from onboarding to exit.',
  'Every request has an owner, a status, and a trail.',
  'Every document, approval, and report in one operating layer.',
];

export function LoginPage() {
  const { login, isAuthenticated, defaultRoute } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [formError, setFormError] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const errorId = useId();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    mode: 'onTouched',
    defaultValues: { email: '', password: '' },
  });

  if (isAuthenticated) {
    const redirectTo = (location.state as { from?: string } | null)?.from ?? defaultRoute;
    return <Navigate to={redirectTo} replace />;
  }

  async function onSubmit(values: FormValues) {
    setFormError(null);
    try {
      await login(values.email, values.password);
      navigate((location.state as { from?: string } | null)?.from ?? '/', { replace: true });
    } catch (error) {
      if (error instanceof ApiError) {
        setFormError(error.status === 422 ? error.fieldError('email') ?? error.message : error.message);
      } else {
        setFormError('We couldn’t reach the server. Check your connection and try again.');
      }
    }
  }

  return (
    <div className="flex min-h-screen bg-surface">
      {/* Brand panel — institutional context, hidden on narrow viewports where
          the form alone is the priority. */}
      <div className="relative hidden w-[42%] flex-col justify-between overflow-hidden bg-pine px-14 py-12 text-white xl:flex">
        <BrandPattern />

        <div className="relative flex items-center gap-2.5">
          <Logomark size={22} />
          <span className="font-display text-[15px] font-semibold tracking-tight">Valtireo</span>
        </div>

        <div className="relative max-w-md">
          <h1 className="font-display text-[28px] font-semibold leading-[1.25] tracking-tight">
            The Organizational OS for modern institutions.
          </h1>
          <p className="mt-4 text-[15px] leading-relaxed text-white/70">
            Structure your people, workflows, approvals, documents, and internal services in one
            connected platform.
          </p>
          <ul className="mt-9 flex flex-col gap-4">
            {PILLARS.map((pillar) => (
              <li key={pillar} className="flex items-start gap-3 text-sm text-white/85">
                <span className="mt-1.5 h-1 w-1 flex-shrink-0 rounded-full bg-teal" aria-hidden />
                {pillar}
              </li>
            ))}
          </ul>
        </div>

        <p className="relative text-xs text-white/45">© {new Date().getFullYear()} Leading Digitals</p>
      </div>

      {/* Form panel */}
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-16 sm:px-12">
        <div className="w-full max-w-[360px]">
          <div className="mb-9 flex items-center gap-2.5 xl:hidden">
            <Logomark size={20} />
            <span className="font-display text-[15px] font-semibold tracking-tight text-strong">Valtireo</span>
          </div>

          <h2 className="font-display text-[22px] font-semibold text-strong">Sign in</h2>
          <p className="mt-1.5 text-sm text-muted">Enter your workspace credentials to continue.</p>

          <form onSubmit={handleSubmit(onSubmit)} className="mt-7 flex flex-col gap-4" noValidate>
            <Field label="Email address" htmlFor="email" error={errors.email?.message} required>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                autoFocus
                invalid={Boolean(errors.email)}
                aria-invalid={Boolean(errors.email)}
                aria-describedby={errors.email ? 'email-error' : undefined}
                {...register('email')}
              />
            </Field>

            <Field label="Password" htmlFor="password" error={errors.password?.message} required>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  invalid={Boolean(errors.password)}
                  aria-invalid={Boolean(errors.password)}
                  aria-describedby={errors.password ? 'password-error' : undefined}
                  className="pr-10"
                  {...register('password')}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  className="absolute inset-y-0 right-0 flex w-9 items-center justify-center text-muted hover:text-strong"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </Field>

            {formError && (
              <Alert id={errorId} tone="danger">
                {formError}
              </Alert>
            )}

            <Button type="submit" variant="primary" className="mt-1 h-10 w-full" isLoading={isSubmitting}>
              {isSubmitting ? 'Signing in…' : 'Sign in'}
            </Button>
          </form>

          <p className="mt-5 text-center text-[13px] text-muted">
            Forgot your password? Contact your workspace administrator.
          </p>

          {import.meta.env.DEV && (
            <div className="mt-8 rounded-md border border-dashed border-border-strong px-3 py-2.5 text-[11px] text-muted">
              <span className="font-medium text-strong">Development only</span> — seeded local admin:
              admin@valtireo.test / Password1!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/** Sparse dot/line motif suggesting a connected structure, kept faint. */
function BrandPattern() {
  return (
    <svg
      className="pointer-events-none absolute inset-0 h-full w-full"
      aria-hidden
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern id="valtireo-grid" width="56" height="56" patternUnits="userSpaceOnUse">
          <circle cx="1" cy="1" r="1" fill="white" fillOpacity="0.16" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#valtireo-grid)" />
      <line x1="0" y1="0" x2="100%" y2="55%" stroke="white" strokeOpacity="0.04" strokeWidth="1" />
      <line x1="20%" y1="0" x2="100%" y2="90%" stroke="white" strokeOpacity="0.04" strokeWidth="1" />
    </svg>
  );
}
