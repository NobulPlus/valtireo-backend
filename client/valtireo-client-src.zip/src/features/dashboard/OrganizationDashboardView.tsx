import { Building2, ClipboardList, UserCheck, Users } from 'lucide-react';
import { useOrganizationDashboard } from '@/features/dashboard/api';
import { LoadingState, ErrorState } from '@/components/ui/States';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { StatTile } from '@/components/ui/StatTile';
import { BreakdownList } from '@/components/ui/BreakdownList';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Link } from 'react-router-dom';

export function OrganizationDashboardView() {
  const { data, isLoading, isError, error, refetch } = useOrganizationDashboard();

  if (isLoading) return <LoadingState label="Loading organization dashboard…" />;
  if (isError) return <ErrorState error={error} onRetry={() => refetch()} />;
  if (!data) return null;

  return (
    <div className="flex flex-col gap-5">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatTile label="Total employees" value={data.employees.total} icon={Users} />
        <StatTile label="Active" value={data.employees.active} tone="success" icon={UserCheck} />
        <StatTile label="Onboarding" value={data.employees.onboarding} icon={ClipboardList} />
        <StatTile label="Departments" value={data.structure.departments} icon={Building2} />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Employees by department</CardTitle>
          </CardHeader>
          <CardBody>
            <BreakdownList
              entries={data.breakdowns.by_department.map((entry) => ({ label: entry.name, total: entry.total }))}
            />
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Setup progress</CardTitle>
          </CardHeader>
          <CardBody>
            <div className="mb-2 flex items-center justify-between text-xs text-muted">
              <span>Workspace setup</span>
              <span>{data.setup_completion.percentage}%</span>
            </div>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-soft">
              <div
                className="h-full rounded-full bg-teal"
                style={{ width: `${data.setup_completion.percentage}%` }}
              />
            </div>
            <Link to="/workspace" className="mt-3 inline-block text-xs font-medium text-teal hover:underline">
              Go to workspace setup →
            </Link>
          </CardBody>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>By employment type</CardTitle>
          </CardHeader>
          <CardBody>
            <BreakdownList
              entries={data.breakdowns.by_employment_type.map((entry) => ({ label: entry.name, total: entry.total }))}
            />
          </CardBody>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>By location</CardTitle>
          </CardHeader>
          <CardBody>
            <BreakdownList
              entries={data.breakdowns.by_location.map((entry) => ({ label: entry.name, total: entry.total }))}
            />
          </CardBody>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recently added employees</CardTitle>
        </CardHeader>
        <CardBody className="p-0">
          {data.recent.employees.length === 0 ? (
            <p className="px-5 py-6 text-sm text-muted">No employees yet.</p>
          ) : (
            <ul className="divide-y divide-border">
              {data.recent.employees.map((employee) => (
                <li key={employee.id}>
                  <Link
                    to={`/employees/${employee.id}`}
                    className="flex items-center justify-between px-5 py-3 text-sm hover:bg-surface-soft"
                  >
                    <div>
                      <p className="font-medium text-strong">{employee.full_name}</p>
                      <p className="text-xs text-muted">
                        {employee.employee_number} · {employee.department?.name ?? 'Unassigned'}
                      </p>
                    </div>
                    {employee.status && <StatusBadge status={employee.status} />}
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
