import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/apiClient';
import { useAuth } from '@/context/AuthContext';
import type { ManagerDashboard, MyDashboard, OrganizationDashboard } from '@/types/api';

export function useOrganizationDashboard() {
  const { hasPermission } = useAuth();
  return useQuery({
    queryKey: ['dashboard', 'organization'],
    queryFn: () => api.get<OrganizationDashboard>('/dashboard/organization'),
    enabled: hasPermission('reports.view'),
  });
}

export function useManagerDashboard() {
  return useQuery({
    queryKey: ['dashboard', 'manager'],
    queryFn: () => api.get<ManagerDashboard>('/dashboard/manager'),
  });
}

export function useMyDashboard() {
  return useQuery({
    queryKey: ['dashboard', 'me'],
    queryFn: () => api.get<MyDashboard>('/dashboard/me'),
  });
}
