import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { Field } from '@/components/ui/Field';
import { Input, Select } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { AsyncSelect, type AsyncOption } from '@/components/ui/AsyncSelect';
import { RequirePermission } from '@/components/shell/RequirePermission';
import { useSetupLookups } from '@/features/workspace/api';
import { searchEmployees, useCreateEmployee } from '@/features/employees/api';
import { ApiError } from '@/lib/apiClient';

const schema = z.object({
  employee_number: z.string().min(1, 'Employee number is required'),
  first_name: z.string().min(1, 'First name is required'),
  middle_name: z.string().optional(),
  last_name: z.string().min(1, 'Last name is required'),
  work_email: z.string().min(1, 'Work email is required').email('Enter a valid email address'),
  phone: z.string().optional(),
  department_id: z.string().min(1, 'Department is required'),
  unit_id: z.string().optional(),
  designation_id: z.string().min(1, 'Designation is required'),
  grade_level_id: z.string().optional(),
  employment_type_id: z.string().min(1, 'Employment type is required'),
  organization_location_id: z.string().min(1, 'Location is required'),
  start_date: z.string().optional(),
  send_invitation: z.boolean(),
});

type FormValues = z.infer<typeof schema>;

function EmployeeCreateContent() {
  const navigate = useNavigate();
  const lookupsQuery = useSetupLookups();
  const createMutation = useCreateEmployee();
  const [reportingManager, setReportingManager] = useState<AsyncOption | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    watch,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      employee_number: '',
      first_name: '',
      middle_name: '',
      last_name: '',
      work_email: '',
      phone: '',
      department_id: '',
      unit_id: '',
      designation_id: '',
      grade_level_id: '',
      employment_type_id: '',
      organization_location_id: '',
      start_date: '',
      send_invitation: true,
    },
  });

  const selectedDepartmentId = watch('department_id');
  const units = useMemo(
    () =>
      (lookupsQuery.data?.units ?? []).filter(
        (unit) => !selectedDepartmentId || String(unit.department_id) === selectedDepartmentId,
      ),
    [lookupsQuery.data, selectedDepartmentId],
  );

  async function onSubmit(values: FormValues) {
    setFormError(null);
    try {
      const result = await createMutation.mutateAsync({
        employee_number: values.employee_number,
        first_name: values.first_name,
        middle_name: values.middle_name || null,
        last_name: values.last_name,
        work_email: values.work_email,
        phone: values.phone || null,
        department_id: Number(values.department_id),
        unit_id: values.unit_id ? Number(values.unit_id) : null,
        designation_id: Number(values.designation_id),
        grade_level_id: values.grade_level_id ? Number(values.grade_level_id) : null,
        employment_type_id: Number(values.employment_type_id),
        organization_location_id: Number(values.organization_location_id),
        reporting_manager_id: reportingManager?.value ?? null,
        start_date: values.start_date || null,
        send_invitation: values.send_invitation,
      });
      navigate(`/employees/${result.employee.id}`);
    } catch (error) {
      if (error instanceof ApiError && error.errors) {
        Object.entries(error.errors).forEach(([field, messages]) => {
          if (field in schema.shape) {
            setError(field as keyof FormValues, { message: messages[0] });
          }
        });
        setFormError(error.message);
      } else if (error instanceof ApiError) {
        setFormError(error.message);
      } else {
        setFormError('Something went wrong. Please try again.');
      }
    }
  }

  return (
    <div>
      <PageHeader
        title="Add employee"
        breadcrumbs={[{ label: 'Employees', to: '/employees' }, { label: 'Add employee' }]}
      />

      <form onSubmit={handleSubmit(onSubmit)} noValidate className="flex flex-col gap-5">
        <Card>
          <CardHeader>
            <CardTitle>Identity</CardTitle>
          </CardHeader>
          <CardBody className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Employee number" htmlFor="employee_number" error={errors.employee_number?.message} required>
              <Input id="employee_number" invalid={Boolean(errors.employee_number)} {...register('employee_number')} />
            </Field>
            <Field label="Work email" htmlFor="work_email" error={errors.work_email?.message} required>
              <Input id="work_email" type="email" invalid={Boolean(errors.work_email)} {...register('work_email')} />
            </Field>
            <Field label="Phone" htmlFor="phone" error={errors.phone?.message}>
              <Input id="phone" {...register('phone')} />
            </Field>
            <Field label="First name" htmlFor="first_name" error={errors.first_name?.message} required>
              <Input id="first_name" invalid={Boolean(errors.first_name)} {...register('first_name')} />
            </Field>
            <Field label="Middle name" htmlFor="middle_name" error={errors.middle_name?.message}>
              <Input id="middle_name" {...register('middle_name')} />
            </Field>
            <Field label="Last name" htmlFor="last_name" error={errors.last_name?.message} required>
              <Input id="last_name" invalid={Boolean(errors.last_name)} {...register('last_name')} />
            </Field>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Structure & assignment</CardTitle>
          </CardHeader>
          <CardBody className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Department" htmlFor="department_id" error={errors.department_id?.message} required>
              <Select id="department_id" invalid={Boolean(errors.department_id)} {...register('department_id')}>
                <option value="">Select department</option>
                {lookupsQuery.data?.departments.map((department) => (
                  <option key={department.id} value={department.id}>
                    {department.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Unit" htmlFor="unit_id" error={errors.unit_id?.message}>
              <Select id="unit_id" {...register('unit_id')}>
                <option value="">Select unit</option>
                {units.map((unit) => (
                  <option key={unit.id} value={unit.id}>
                    {unit.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Designation" htmlFor="designation_id" error={errors.designation_id?.message} required>
              <Select id="designation_id" invalid={Boolean(errors.designation_id)} {...register('designation_id')}>
                <option value="">Select designation</option>
                {lookupsQuery.data?.designations.map((designation) => (
                  <option key={designation.id} value={designation.id}>
                    {designation.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Grade level" htmlFor="grade_level_id" error={errors.grade_level_id?.message}>
              <Select id="grade_level_id" {...register('grade_level_id')}>
                <option value="">Select grade level</option>
                {lookupsQuery.data?.grade_levels.map((level) => (
                  <option key={level.id} value={level.id}>
                    {level.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field
              label="Employment type"
              htmlFor="employment_type_id"
              error={errors.employment_type_id?.message}
              required
            >
              <Select
                id="employment_type_id"
                invalid={Boolean(errors.employment_type_id)}
                {...register('employment_type_id')}
              >
                <option value="">Select employment type</option>
                {lookupsQuery.data?.employment_types.map((type) => (
                  <option key={type.id} value={type.id}>
                    {type.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field
              label="Location"
              htmlFor="organization_location_id"
              error={errors.organization_location_id?.message}
              required
            >
              <Select
                id="organization_location_id"
                invalid={Boolean(errors.organization_location_id)}
                {...register('organization_location_id')}
              >
                <option value="">Select location</option>
                {lookupsQuery.data?.locations.map((location) => (
                  <option key={location.id} value={location.id}>
                    {location.name}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Reporting manager" htmlFor="reporting_manager_id">
              <AsyncSelect
                value={reportingManager}
                onChange={setReportingManager}
                placeholder="Search employees…"
                loadOptions={async (query) => {
                  const results = await searchEmployees(query);
                  return results.map((employee) => ({
                    value: employee.id,
                    label: employee.full_name,
                    description: employee.employee_number,
                  }));
                }}
              />
            </Field>
            <Field label="Start date" htmlFor="start_date" error={errors.start_date?.message}>
              <Input id="start_date" type="date" {...register('start_date')} />
            </Field>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Onboarding</CardTitle>
          </CardHeader>
          <CardBody>
            <label className="flex items-start gap-3 text-sm">
              <input type="checkbox" className="mt-0.5 h-4 w-4 rounded border-border" {...register('send_invitation')} />
              <span>
                <span className="block font-medium text-strong">Send invitation email</span>
                <span className="block text-muted">
                  The employee will receive an invitation to set a password and complete their profile. Leave this
                  unchecked to create a draft record you can invite later.
                </span>
              </span>
            </label>
          </CardBody>
        </Card>

        {formError && (
          <p className="rounded-md bg-danger-bg px-3 py-2 text-sm text-danger">
            {formError}
          </p>
        )}

        <div className="flex items-center gap-2">
          <Button type="submit" variant="primary" isLoading={isSubmitting}>
            Create employee
          </Button>
          <Button type="button" variant="ghost" onClick={() => navigate('/employees')}>
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}

export function EmployeeCreatePage() {
  return (
    <RequirePermission permission="employees.create">
      <EmployeeCreateContent />
    </RequirePermission>
  );
}
