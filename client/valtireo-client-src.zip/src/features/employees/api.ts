import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, apiClient } from '@/lib/apiClient';
import type { CreateEmployeePayload, CreateEmployeeResponse, Employee, Paginated } from '@/types/api';

export interface EmployeeFilters {
  search?: string;
  status?: string;
  department_id?: number;
  unit_id?: number;
  designation_id?: number;
  grade_level_id?: number;
  employment_type_id?: number;
  organization_location_id?: number;
  profile_status?: string;
  sort_by?: string;
  sort_direction?: 'asc' | 'desc';
  page?: number;
  per_page?: number;
}

function cleanParams<T extends object>(filters: T): Partial<T> {
  return Object.fromEntries(
    Object.entries(filters).filter(([, value]) => value !== undefined && value !== null && value !== ''),
  ) as Partial<T>;
}

export function useEmployees(filters: EmployeeFilters) {
  return useQuery({
    queryKey: ['employees', filters],
    queryFn: () => api.get<Paginated<Employee>>('/employees', { params: cleanParams(filters) }),
    placeholderData: (previous) => previous,
  });
}

export function useEmployee(id: number | string | undefined) {
  return useQuery({
    queryKey: ['employees', id],
    queryFn: () => api.get<Employee>(`/employees/${id}`),
    enabled: id !== undefined,
  });
}

/** Lightweight employee search used by the reporting-manager async select. */
export async function searchEmployees(query: string): Promise<Employee[]> {
  const result = await api.get<Paginated<Employee>>('/employees', {
    params: cleanParams({ search: query, per_page: 10 }),
  });
  return result.data;
}

export function useCreateEmployee() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (payload: CreateEmployeePayload) =>
      api.post<CreateEmployeeResponse>('/employees', payload),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

export function useApproveOnboarding(employeeId: number) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: () => api.patch<{ employee: Employee }>(`/employees/${employeeId}/approve-onboarding`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employees', employeeId] });
      queryClient.invalidateQueries({ queryKey: ['employees'] });
    },
  });
}

/**
 * Streams the employees CSV export and triggers a browser download. A plain
 * <a href> won't carry the bearer token, so this fetches via the shared
 * axios client (which attaches Authorization) and saves the blob.
 */
export async function downloadEmployeesCsv(filters: EmployeeFilters): Promise<void> {
  const response = await apiClient.get('/employees/export', {
    params: cleanParams({ ...filters, format: 'csv' }),
    responseType: 'blob',
  });
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.download = `employees-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(url);
}
