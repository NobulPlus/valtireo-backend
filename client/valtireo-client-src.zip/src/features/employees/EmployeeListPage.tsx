import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Download, Plus, Search, UserRound } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input, Select } from '@/components/ui/Input';
import { DataTable, type Column } from '@/components/ui/DataTable';
import { Pagination } from '@/components/ui/Pagination';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/States';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { RequirePermission } from '@/components/shell/RequirePermission';
import { useAuth } from '@/context/AuthContext';
import { useSetupLookups } from '@/features/workspace/api';
import { downloadEmployeesCsv, useEmployees, type EmployeeFilters } from '@/features/employees/api';
import type { Employee } from '@/types/api';

const STATUS_OPTIONS = ['draft', 'invited', 'onboarding', 'active', 'suspended', 'exited'];

function useDebouncedValue<T>(value: T, delay = 350): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timeout = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timeout);
  }, [value, delay]);
  return debounced;
}

function EmployeeListContent() {
  const navigate = useNavigate();
  const { hasPermission } = useAuth();
  const lookupsQuery = useSetupLookups();

  const [search, setSearch] = useState('');
  const debouncedSearch = useDebouncedValue(search);
  const [status, setStatus] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [page, setPage] = useState(1);
  const [exporting, setExporting] = useState(false);

  const filters: EmployeeFilters = useMemo(
    () => ({
      search: debouncedSearch || undefined,
      status: status || undefined,
      department_id: departmentId ? Number(departmentId) : undefined,
      page,
      per_page: 15,
    }),
    [debouncedSearch, status, departmentId, page],
  );

  const { data, isLoading, isError, error, refetch, isFetching } = useEmployees(filters);

  async function handleExport() {
    setExporting(true);
    try {
      await downloadEmployeesCsv(filters);
    } finally {
      setExporting(false);
    }
  }

  const columns: Column<Employee>[] = [
    {
      key: 'name',
      header: 'Employee',
      render: (row) => (
        <div>
          <p className="font-medium text-strong">{row.full_name}</p>
          <p className="text-xs text-muted">{row.employee_number}</p>
        </div>
      ),
    },
    { key: 'department', header: 'Department', render: (row) => row.department?.name ?? '—' },
    { key: 'designation', header: 'Designation', render: (row) => row.designation?.name ?? '—' },
    { key: 'location', header: 'Location', render: (row) => row.location?.name ?? '—' },
    { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
    {
      key: 'profile',
      header: 'Profile',
      render: (row) => (row.profile ? <StatusBadge status={row.profile.completion_status} /> : '—'),
    },
  ];

  return (
    <div>
      <PageHeader
        title="Employees"
        subtitle="Search, filter, and manage every employee record in your workspace."
        actions={
          <>
            <Button variant="secondary" onClick={handleExport} isLoading={exporting}>
              <Download className="h-3.5 w-3.5" /> Export CSV
            </Button>
            {hasPermission('employees.create') && (
              <Button variant="primary" onClick={() => navigate('/employees/new')}>
                <Plus className="h-3.5 w-3.5" /> Add employee
              </Button>
            )}
          </>
        }
      />

      <Card>
        <div className="flex flex-col gap-3 border-b border-border p-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
            <Input
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setPage(1);
              }}
              placeholder="Search by name, number, or email…"
              className="pl-9"
            />
          </div>
          <Select
            value={status}
            onChange={(event) => {
              setStatus(event.target.value);
              setPage(1);
            }}
            className="sm:w-44"
          >
            <option value="">All statuses</option>
            {STATUS_OPTIONS.map((option) => (
              <option key={option} value={option}>
                {option.charAt(0).toUpperCase() + option.slice(1)}
              </option>
            ))}
          </Select>
          <Select
            value={departmentId}
            onChange={(event) => {
              setDepartmentId(event.target.value);
              setPage(1);
            }}
            className="sm:w-52"
          >
            <option value="">All departments</option>
            {lookupsQuery.data?.departments.map((department) => (
              <option key={department.id} value={department.id}>
                {department.name}
              </option>
            ))}
          </Select>
        </div>

        {isLoading && <LoadingState label="Loading employees…" />}
        {isError && <ErrorState error={error} onRetry={() => refetch()} />}

        {data && data.data.length === 0 && (
          <EmptyState
            icon={<UserRound className="h-6 w-6" />}
            title="No employees found"
            description="Try adjusting your filters, or add your first employee."
          />
        )}

        {data && data.data.length > 0 && (
          <>
            <div className={isFetching ? 'opacity-60 transition-opacity' : ''}>
              <DataTable
                columns={columns}
                rows={data.data}
                rowKey={(row) => row.id}
                onRowClick={(row) => navigate(`/employees/${row.id}`)}
              />
            </div>
            <Pagination meta={data.meta} onPageChange={setPage} />
          </>
        )}
      </Card>
    </div>
  );
}

export function EmployeeListPage() {
  return (
    <RequirePermission permission="employees.view">
      <EmployeeListContent />
    </RequirePermission>
  );
}
