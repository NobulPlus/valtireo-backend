import { useState, type ReactNode } from 'react';
import { useParams } from 'react-router-dom';
import { CheckCircle2, Mail, MapPin, Phone } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { LoadingState, ErrorState, EmptyState } from '@/components/ui/States';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { Button } from '@/components/ui/Button';
import { Modal } from '@/components/ui/Modal';
import { RequirePermission } from '@/components/shell/RequirePermission';
import { useAuth } from '@/context/AuthContext';
import { useApproveOnboarding, useEmployee } from '@/features/employees/api';
import { cn } from '@/lib/cn';
import { ApiError } from '@/lib/apiClient';

type Tab = 'overview' | 'documents' | 'status' | 'reporting' | 'activity';

const TABS: { key: Tab; label: string }[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'documents', label: 'Documents' },
  { key: 'status', label: 'Status history' },
  { key: 'reporting', label: 'Reporting history' },
  { key: 'activity', label: 'Activity' },
];

function EmployeeDetailContent() {
  const { id } = useParams<{ id: string }>();
  const { hasPermission } = useAuth();
  const { data: employee, isLoading, isError, error, refetch } = useEmployee(id);
  const [tab, setTab] = useState<Tab>('overview');
  const [confirmApprove, setConfirmApprove] = useState(false);
  const approveMutation = useApproveOnboarding(Number(id));

  if (isLoading) return <LoadingState label="Loading employee…" />;
  if (isError) return <ErrorState error={error} onRetry={() => refetch()} />;
  if (!employee) return null;

  const canApprove = hasPermission('employees.update') && employee.status === 'onboarding';

  return (
    <div>
      <PageHeader
        title={employee.full_name}
        breadcrumbs={[{ label: 'Employees', to: '/employees' }, { label: employee.full_name }]}
        status={<StatusBadge status={employee.status} />}
        subtitle={`${employee.employee_number} · ${employee.designation?.name ?? 'No designation'} · ${
          employee.department?.name ?? 'No department'
        }`}
        actions={
          canApprove && (
            <Button variant="primary" onClick={() => setConfirmApprove(true)}>
              <CheckCircle2 className="h-3.5 w-3.5" /> Approve onboarding
            </Button>
          )
        }
      />

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Contact</CardTitle>
          </CardHeader>
          <CardBody className="flex flex-col gap-2.5 text-sm">
            <div className="flex items-center gap-2 text-strong">
              <Mail className="h-3.5 w-3.5 text-muted" /> {employee.work_email}
            </div>
            {employee.phone && (
              <div className="flex items-center gap-2 text-strong">
                <Phone className="h-3.5 w-3.5 text-muted" /> {employee.phone}
              </div>
            )}
            {employee.location && (
              <div className="flex items-center gap-2 text-strong">
                <MapPin className="h-3.5 w-3.5 text-muted" /> {employee.location.name}
              </div>
            )}
            {employee.profile && (
              <div className="mt-2 flex items-center justify-between border-t border-border pt-2.5">
                <span className="text-muted">Profile</span>
                <StatusBadge status={employee.profile.completion_status} />
              </div>
            )}
          </CardBody>
        </Card>

        <div className="lg:col-span-2">
          <div className="mb-4 flex items-center gap-1 border-b border-border">
            {TABS.map((tabItem) => (
              <button
                key={tabItem.key}
                onClick={() => setTab(tabItem.key)}
                className={cn(
                  'border-b-2 px-3 pb-2.5 text-sm font-medium transition-colors',
                  tab === tabItem.key
                    ? 'border-pine text-pine'
                    : 'border-transparent text-muted hover:text-strong',
                )}
              >
                {tabItem.label}
              </button>
            ))}
          </div>

          {tab === 'overview' && (
            <Card>
              <CardBody className="grid grid-cols-1 gap-y-3 text-sm sm:grid-cols-2">
                <OverviewRow label="Employee number" value={employee.employee_number} />
                <OverviewRow label="Status" value={<StatusBadge status={employee.status} />} />
                <OverviewRow label="Department" value={employee.department?.name ?? '—'} />
                <OverviewRow label="Unit" value={employee.unit?.name ?? '—'} />
                <OverviewRow label="Designation" value={employee.designation?.name ?? '—'} />
                <OverviewRow label="Grade level" value={employee.grade_level?.name ?? '—'} />
                <OverviewRow label="Employment type" value={employee.employment_type?.name ?? '—'} />
                <OverviewRow label="Location" value={employee.location?.name ?? '—'} />
                <OverviewRow label="Start date" value={employee.start_date ?? '—'} />
                <OverviewRow label="Invited" value={employee.invited_at ?? 'Not invited'} />
                <OverviewRow label="Onboarding completed" value={employee.onboarding_completed_at ?? '—'} />
                <OverviewRow label="Activated" value={employee.activated_at ?? '—'} />
              </CardBody>
            </Card>
          )}

          {tab === 'documents' && (
            <Card>
              <CardBody className="p-0">
                {employee.documents && employee.documents.length > 0 ? (
                  <ul className="divide-y divide-border">
                    {employee.documents.map((doc) => (
                      <li key={doc.id} className="flex items-center justify-between px-5 py-3 text-sm">
                        <div>
                          <p className="font-medium text-strong">{doc.title}</p>
                          <p className="text-xs text-muted">{doc.document_type?.name}</p>
                        </div>
                        <StatusBadge status={doc.status} />
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState title="No documents yet" description="Documents submitted for this employee will appear here." />
                )}
              </CardBody>
            </Card>
          )}

          {tab === 'status' && (
            <Card>
              <CardBody className="p-0">
                {employee.status_history && employee.status_history.length > 0 ? (
                  <ul className="divide-y divide-border">
                    {employee.status_history.map((entry) => (
                      <li key={entry.id} className="px-5 py-3 text-sm">
                        <div className="flex items-center justify-between">
                          <StatusBadge status={entry.new_status} />
                          <span className="text-xs text-muted">{entry.effective_date}</span>
                        </div>
                        {entry.reason && <p className="mt-1 text-strong">{entry.reason}</p>}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState title="No status changes yet" />
                )}
              </CardBody>
            </Card>
          )}

          {tab === 'reporting' && (
            <Card>
              <CardBody className="p-0">
                {employee.reporting_history && employee.reporting_history.length > 0 ? (
                  <ul className="divide-y divide-border">
                    {employee.reporting_history.map((entry) => (
                      <li key={entry.id} className="px-5 py-3 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="text-strong">
                            {entry.previous_manager?.full_name ?? 'Unassigned'} →{' '}
                            {entry.new_manager?.full_name ?? 'Unassigned'}
                          </span>
                          <span className="text-xs text-muted">{entry.effective_date}</span>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState title="No reporting changes yet" />
                )}
              </CardBody>
            </Card>
          )}

          {tab === 'activity' && (
            <Card>
              <CardBody className="p-0">
                {employee.activities && employee.activities.length > 0 ? (
                  <ul className="divide-y divide-border">
                    {employee.activities.map((activity) => (
                      <li key={activity.id} className="px-5 py-3 text-sm">
                        <p className="font-medium text-strong">{activity.title}</p>
                        {activity.description && <p className="text-muted">{activity.description}</p>}
                        <p className="mt-1 text-xs text-muted">
                          {activity.actor?.name ?? 'System'} · {activity.created_at}
                        </p>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <EmptyState title="No activity recorded yet" />
                )}
              </CardBody>
            </Card>
          )}
        </div>
      </div>

      <Modal
        open={confirmApprove}
        onClose={() => setConfirmApprove(false)}
        title="Approve onboarding"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmApprove(false)}>
              Cancel
            </Button>
            <Button
              variant="primary"
              isLoading={approveMutation.isPending}
              onClick={async () => {
                await approveMutation.mutateAsync();
                setConfirmApprove(false);
              }}
            >
              Approve
            </Button>
          </>
        }
      >
        <p>
          This confirms {employee.full_name}'s onboarding is complete and activates their record. This action is
          recorded to the audit trail.
        </p>
        {approveMutation.isError && (
          <p className="mt-2 text-sm text-danger">
            {approveMutation.error instanceof ApiError ? approveMutation.error.message : 'Could not approve onboarding.'}
          </p>
        )}
      </Modal>
    </div>
  );
}

function OverviewRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-border py-2 last:border-b-0 sm:border-b-0">
      <span className="text-muted">{label}</span>
      <span className="font-medium text-strong">{value}</span>
    </div>
  );
}

export function EmployeeDetailPage() {
  return (
    <RequirePermission permission="employees.view">
      <EmployeeDetailContent />
    </RequirePermission>
  );
}
