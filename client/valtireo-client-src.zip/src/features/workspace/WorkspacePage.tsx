import { useEffect, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { CheckCircle2, Circle } from 'lucide-react';
import { PageHeader } from '@/components/ui/PageHeader';
import { Card, CardBody, CardHeader, CardTitle } from '@/components/ui/Card';
import { LoadingState, ErrorState } from '@/components/ui/States';
import { Field } from '@/components/ui/Field';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { RequirePermission } from '@/components/shell/RequirePermission';
import { useSetupChecklist, useWorkspace } from '@/features/workspace/api';
import { api, ApiError } from '@/lib/apiClient';
import type { WorkspaceSettings } from '@/types/api';
import { cn } from '@/lib/cn';

function WorkspaceContent() {
  const workspaceQuery = useWorkspace();
  const checklistQuery = useSetupChecklist();
  const queryClient = useQueryClient();

  const [form, setForm] = useState<{
    welcome_message: string;
    support_email: string;
    primary_color: string;
    accent_color: string;
    timezone: string;
    date_format: string;
    currency: string;
  } | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const workspace = workspaceQuery.data?.workspace;
    if (workspace && !form) {
      setForm({
        welcome_message: workspace.identity.welcome_message,
        support_email: workspace.identity.support_email ?? '',
        primary_color: workspace.theme.primary_color,
        accent_color: workspace.theme.accent_color,
        timezone: workspace.localization.timezone,
        date_format: workspace.localization.date_format,
        currency: workspace.localization.currency,
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspaceQuery.data]);

  const updateMutation = useMutation({
    mutationFn: () =>
      api.patch<{ workspace: WorkspaceSettings }>('/workspace/settings', {
        identity: {
          welcome_message: form?.welcome_message,
          support_email: form?.support_email || null,
        },
        theme: {
          primary_color: form?.primary_color,
          accent_color: form?.accent_color,
        },
        localization: {
          timezone: form?.timezone,
          date_format: form?.date_format,
          currency: form?.currency,
        },
      }),
    onSuccess: () => {
      setSaved(true);
      queryClient.invalidateQueries({ queryKey: ['workspace'] });
      setTimeout(() => setSaved(false), 2500);
    },
  });

  if (workspaceQuery.isLoading) return <LoadingState label="Loading workspace…" />;
  if (workspaceQuery.isError) return <ErrorState error={workspaceQuery.error} onRetry={() => workspaceQuery.refetch()} />;

  const workspace = workspaceQuery.data?.workspace;
  if (!workspace || !form) return null;

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="flex flex-col gap-5 lg:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle>Organization identity</CardTitle>
          </CardHeader>
          <CardBody>
            <form
              className="grid grid-cols-1 gap-4 sm:grid-cols-2"
              onSubmit={(event) => {
                event.preventDefault();
                updateMutation.mutate();
              }}
            >
              <Field label="Welcome message" className="sm:col-span-2">
                <Input
                  value={form.welcome_message}
                  onChange={(event) => setForm({ ...form, welcome_message: event.target.value })}
                />
              </Field>
              <Field label="Support email">
                <Input
                  type="email"
                  value={form.support_email}
                  onChange={(event) => setForm({ ...form, support_email: event.target.value })}
                  placeholder="support@yourorg.com"
                />
              </Field>
              <Field label="Timezone">
                <Input
                  value={form.timezone}
                  onChange={(event) => setForm({ ...form, timezone: event.target.value })}
                />
              </Field>
              <Field label="Date format">
                <Input
                  value={form.date_format}
                  onChange={(event) => setForm({ ...form, date_format: event.target.value })}
                />
              </Field>
              <Field label="Currency">
                <Input
                  value={form.currency}
                  onChange={(event) => setForm({ ...form, currency: event.target.value })}
                />
              </Field>
              <Field label="Primary color">
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={form.primary_color}
                    onChange={(event) => setForm({ ...form, primary_color: event.target.value })}
                    className="h-9 w-10 rounded-md border border-border"
                  />
                  <Input
                    value={form.primary_color}
                    onChange={(event) => setForm({ ...form, primary_color: event.target.value })}
                  />
                </div>
              </Field>
              <Field label="Accent color">
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={form.accent_color}
                    onChange={(event) => setForm({ ...form, accent_color: event.target.value })}
                    className="h-9 w-10 rounded-md border border-border"
                  />
                  <Input
                    value={form.accent_color}
                    onChange={(event) => setForm({ ...form, accent_color: event.target.value })}
                  />
                </div>
              </Field>

              <div className="flex items-center gap-3 sm:col-span-2">
                <Button type="submit" variant="primary" isLoading={updateMutation.isPending}>
                  Save changes
                </Button>
                {saved && <span className="text-sm text-success">Saved to the audit trail.</span>}
                {updateMutation.isError && (
                  <span className="text-sm text-danger">
                    {updateMutation.error instanceof ApiError
                      ? updateMutation.error.message
                      : 'Could not save changes.'}
                  </span>
                )}
              </div>
            </form>
          </CardBody>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Employee experience</CardTitle>
          </CardHeader>
          <CardBody className="grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
            <SettingRow label="Employee directory" enabled={workspace.employee_experience.allow_employee_directory} />
            <SettingRow label="Org chart" enabled={workspace.employee_experience.show_org_chart} />
            <SettingRow
              label="Profile self-corrections"
              enabled={workspace.employee_experience.allow_profile_corrections}
            />
          </CardBody>
        </Card>
      </div>

      <div>
        <Card>
          <CardHeader>
            <CardTitle>Setup checklist</CardTitle>
          </CardHeader>
          <CardBody>
            {checklistQuery.isLoading && <LoadingState label="Loading checklist…" />}
            {checklistQuery.isError && (
              <p className="text-sm text-muted">Checklist unavailable for your role.</p>
            )}
            {checklistQuery.data && (
              <div className="flex flex-col gap-3">
                <div>
                  <div className="mb-1 flex items-center justify-between text-xs text-muted">
                    <span>Progress</span>
                    <span>{checklistQuery.data.percentage}%</span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-soft">
                    <div
                      className="h-full rounded-full bg-teal"
                      style={{ width: `${checklistQuery.data.percentage}%` }}
                    />
                  </div>
                </div>
                <ul className="flex flex-col gap-2">
                  {checklistQuery.data.items.map((item) => (
                    <li key={item.key} className="flex items-start gap-2 text-sm">
                      {item.completed ? (
                        <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-success" />
                      ) : (
                        <Circle className="mt-0.5 h-4 w-4 flex-shrink-0 text-muted" />
                      )}
                      <span className={cn(item.completed ? 'text-muted line-through' : 'text-strong')}>
                        {item.label}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

function SettingRow({ label, enabled }: { label: string; enabled: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-border px-3 py-2">
      <span className="text-strong">{label}</span>
      <span className={cn('text-xs font-medium', enabled ? 'text-success' : 'text-muted')}>
        {enabled ? 'Enabled' : 'Disabled'}
      </span>
    </div>
  );
}

export function WorkspacePage() {
  return (
    <div>
      <PageHeader
        title="Workspace"
        subtitle="Organization identity, theme, localization, and setup progress."
      />
      <RequirePermission permission="workspace_settings.view">
        <WorkspaceContent />
      </RequirePermission>
    </div>
  );
}
