import type { LucideIcon } from 'lucide-react';
import {
  BadgeCheck,
  BarChart3,
  Building2,
  CalendarClock,
  ClipboardCheck,
  FileStack,
  Gauge,
  ScrollText,
  Settings,
  Users,
} from 'lucide-react';

export interface NavItem {
  label: string;
  to: string;
  icon: LucideIcon;
  /** Permission required to see this item. Omit for always-visible items. */
  permission?: string;
  /** Module key required to see this item (hidden entirely if not entitled). */
  moduleKey?: string;
  /** Screens not yet built in this pass — shown for roadmap context, disabled. */
  comingSoon?: boolean;
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}

/**
 * Sidebar structure follows the brand/product design foundation doc's
 * groups: Core, People, Workflows, Documents, Time, Reports, Governance,
 * Settings. Items are hidden when the user's module/permission set doesn't
 * entitle them (per the handoff guide's "Hide navigation when the module is
 * unavailable" rule); a few not-yet-built screens are kept visible-but-
 * disabled so the shell communicates the full product shape.
 */
export const NAV_GROUPS: NavGroup[] = [
  {
    label: 'Core',
    items: [{ label: 'Dashboard', to: '/dashboard', icon: Gauge }],
  },
  {
    label: 'People',
    items: [
      { label: 'Employees', to: '/employees', icon: Users, permission: 'employees.view' },
    ],
  },
  {
    label: 'Documents',
    items: [
      {
        label: 'Documents & compliance',
        to: '/documents',
        icon: FileStack,
        moduleKey: 'documents',
        comingSoon: true,
      },
    ],
  },
  {
    label: 'Workflows',
    items: [
      {
        label: 'Approvals',
        to: '/approvals',
        icon: ClipboardCheck,
        permission: 'approvals.view',
        comingSoon: true,
      },
    ],
  },
  {
    label: 'Time',
    items: [
      { label: 'Leave', to: '/leave', icon: CalendarClock, moduleKey: 'leave', comingSoon: true },
      {
        label: 'Attendance',
        to: '/attendance',
        icon: BadgeCheck,
        moduleKey: 'attendance',
        comingSoon: true,
      },
    ],
  },
  {
    label: 'Reports',
    items: [
      {
        label: 'Reports',
        to: '/reports',
        icon: BarChart3,
        permission: 'reports.view',
        comingSoon: true,
      },
    ],
  },
  {
    label: 'Governance',
    items: [
      {
        label: 'Audit & activity',
        to: '/audit',
        icon: ScrollText,
        permission: 'audit_logs.view',
        comingSoon: true,
      },
    ],
  },
  {
    label: 'Settings',
    items: [
      {
        label: 'Workspace',
        to: '/workspace',
        icon: Settings,
        permission: 'workspace_settings.view',
      },
      {
        label: 'Organization structure',
        to: '/settings/structure',
        icon: Building2,
        permission: 'workspace_settings.update',
        comingSoon: true,
      },
    ],
  },
];
