/**
 * The Valtireo mark: two connected angled planes forming a structural "V",
 * per the brand foundation doc's logo direction ("a structured V mark made
 * from connected planes... suggesting direction, structure, movement").
 * Deliberately not a checkmark, not a literal letterform stroke, and not a
 * generic people/gear/globe/shield icon (all flagged to avoid in the brand
 * doc) — it's built from two solid quadrilaterals with a shared vertex.
 */
export function Logomark({ size = 28, withBackground = true }: { size?: number; withBackground?: boolean }) {
  const mark = (
    <svg viewBox="0 0 32 32" width={size} height={size} fill="none" xmlns="http://www.w3.org/2000/svg">
      <polygon points="8,6.5 13.4,6.5 17.6,24.5 12.2,24.5" fill="#2F8F8A" />
      <polygon points="24,6.5 18.6,6.5 14.4,24.5 19.8,24.5" fill="#2F8F8A" fillOpacity="0.55" />
    </svg>
  );

  if (!withBackground) return mark;

  return (
    <div
      className="flex flex-shrink-0 items-center justify-center rounded-lg bg-pine"
      style={{ width: size + 12, height: size + 12 }}
    >
      {mark}
    </div>
  );
}
